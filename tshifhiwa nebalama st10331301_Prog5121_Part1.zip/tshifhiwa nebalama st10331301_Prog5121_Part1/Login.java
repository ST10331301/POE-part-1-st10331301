/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registration.pkg1;

import java.util.Scanner;

public class Login {
     
// Creating a Scanner object to read input from the user
    private static final Scanner sc = new Scanner(System.in);

// loginUser method takes in username, password, registered usernames and passwords arrays,
    // and returns true if the username and password match any of the registered username and password pairs

    public static boolean loginUser(String username, String password, String[] registeredUsernames, String[] registeredPasswords) {
     // Loop through all the registered usernames and passwords   
        for (int i = 0; i < registeredUsernames.length; i++) {
            // Checking if the current username and password match the provided ones
            if (registeredUsernames[i].equals(username) && registeredPasswords[i].equals(password)) {
                // If there is a match, return true
                return true;
            }
        }
        return false;
    }

   // returnLoginStatus method takes in username, password, registered usernames, passwords, first names, and last names arrays
    // and returns a welcome message if the username and password match any of the registered username and password pairs
    // otherwise, it returns an error message
    
    public static String returnLoginStatus(String username, String password, String[] registeredUsernames, String[] registeredPasswords, String[] registeredFirstNames, String[] registeredLastNames) {
     // Calling the loginUser method to check if the provided username and password match any of the registered ones   
        if (loginUser(username, password, registeredUsernames, registeredPasswords)) {
            // If there is a match, find the index of the registered username in the array
            int index = 0;
            for (int i = 0; i < registeredUsernames.length; i++) {
                if (registeredUsernames[i].equals(username)) {
                    index = i;
                    break;
                }
            }
             // Using the index to get the user's first and last name from the corresponding arrays
            // Combining them with a welcome message and return the result
            return "Welcome " + registeredFirstNames[index] + " " + registeredLastNames[index] + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}