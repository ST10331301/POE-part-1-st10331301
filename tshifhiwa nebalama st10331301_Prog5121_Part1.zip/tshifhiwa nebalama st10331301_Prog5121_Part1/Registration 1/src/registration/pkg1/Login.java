/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registration.pkg1;

import java.util.Scanner;

public class Login {
     

    // Create a Scanner object for user input
    private static final Scanner sc = new Scanner(System.in);

    // Method to check if the provided username and password match any of the registered usernames and passwords
    public static boolean loginUser(String username, String password, String[] registeredUsernames, String[] registeredPasswords) {
        for (int i = 0; i < registeredUsernames.length; i++) {
            if (registeredUsernames[i].equals(username) && registeredPasswords[i].equals(password)) {
                return true;
            }
        }
        return false;
    }

// Way to get a string back with the login status based on the password and username entered
    public static String returnLoginStatus(String username, String password, String[] registeredUsernames, String[] registeredPasswords, String[] registeredFirstNames, String[] registeredLastNames) {
        if (loginUser(username, password, registeredUsernames, registeredPasswords)) {
            int index = 0;
            for (int i = 0; i < registeredUsernames.length; i++) {
                if (registeredUsernames[i].equals(username)) {
                    index = i;
                    break;
                }
            }
              // Return a welcome message with the first and last name of the registered user
            return "Welcome " + registeredFirstNames[index] + " " + registeredLastNames[index] + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}