/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registration.pkg1;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Registration1 {
    
      // create scanner object to read user input
    private static final Scanner scanner = new Scanner(System.in);
    
    // create regex patterns for username and password validation
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^\\w{1,5}_\\w+$");
    private static final Pattern PASSWORD_PATTERN = Pattern.compile("^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]).{8,}$");
      
    public static void main(String[] args) {
        
        // print registration title to the output
        System.out.println("Registration");
        System.out.println("********************");
        
         // initialize variables to hold user registration information
        String username = "";
        String password = "";
        String firstName = "";
        String lastName = "";

        // using a loop to validate user input for username
        boolean validUsername = false;
        while (!validUsername) {
            System.out.print("Enter username : ");
            username = scanner.nextLine();
            validUsername = checkUserName(username);
            if (!validUsername) {
                
                // prompt the user to enter a valid username
                System.out.println("Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.");
                
               
            }
        }

        // use a loop to validate user input for password
        boolean validPassword = false;
        while (!validPassword) {
            System.out.print("Enter password : ");
            password = scanner.nextLine();
            validPassword = checkPasswordComplexity(password);
            if (!validPassword) {
                
                // prompting the user to enter a valid password
                System.out.println("Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            }
        }

        // prompting the user to enter their first and last name
        System.out.print("Enter first name: ");
        firstName = scanner.nextLine();
        System.out.print("Enter last name: ");
        lastName = scanner.nextLine();

        // enrolling the user and showing a notice about registration
        String registrationMessage = registerUser(username, password,firstName,lastName);
        System.out.println(registrationMessage);
        
        System.out.println("********************");
        
    // printing the output's login title
        System.out.println("Login");
        System.out.println("********************");
        
       // building arrays to hold data about logged-in users
        String[] registeredUsernames = new String[] {username};
        String[] registeredPasswords = new String[] {password};
        String[] registeredFirstNames = new String[] {firstName};
        String[] registeredLastNames = new String[] {lastName};
        
       // utilizing a loop to verify login user input
        System.out.print("Enter username: ");
        username = scanner.nextLine();
        System.out.print("Enter password: ");
        password = scanner.nextLine();
        
       // authenticating the user and display a login status message
        String loginStatus = Login.returnLoginStatus(username, password, registeredUsernames, registeredPasswords, registeredFirstNames, registeredLastNames);

        System.out.println("********************");
        System.out.println(loginStatus); 
        System.out.println("*********************");
        
        
         
    }

   // using regex to validate the format of the entered username
    public static boolean checkUserName(String username) {
        Matcher matcher = USERNAME_PATTERN.matcher(username);
        return matcher.matches();
    }

   //Verifying if the supplied password satisfies the required level of complexity
    public static boolean checkPasswordComplexity(String password) {
        Matcher matcher = PASSWORD_PATTERN.matcher(password);
        return matcher.matches();
    }

   //Creating a user account using the username, password, first and last names that have been supplied.
    public static String registerUser(String username, String password,String firstName, String lastName) {
        boolean validUsername = checkUserName(username);
        boolean validPassword = checkPasswordComplexity(password);

        if (!validUsername) {
            return "Registration failed: username is not correctly formatted.";
        } else if (!validPassword) {
            return "Registration failed: password is not correctly formatted.";
        } else {
            return "Registration successful!";
           
        }
        
    }
}








