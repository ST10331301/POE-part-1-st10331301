/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registration.pkg1;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Registration1 {
    // Creating scanner objects for user input
    private static final Scanner scanner = new Scanner(System.in);
    private static final Scanner sc = new Scanner(System.in);
    // Defining regex patterns for username and password validation

    private static final Pattern USERNAME_PATTERN = Pattern.compile("^\\w{1,5}_\\w+$");
    private static final Pattern PASSWORD_PATTERN = Pattern.compile("^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]).{8,}$");
    
    
    public static void main(String[] args) {
        System.out.println("Registration");
        System.out.println("********************");
        // Initializing variables for user input
        String username = "";
        String password = "";
        String firstName = "";
        String lastName = "";

        // Looping until a valid username is entered
        boolean validUsername = false;
        while (!validUsername) {
            System.out.print("Enter username : ");
            username = scanner.nextLine();
            validUsername = checkUserName(username);
            if (!validUsername) {
                System.out.println("Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.");
                
               
            }
        }

        boolean validPassword = false;
        while (!validPassword) {
            System.out.print("Enter password : ");
            password = scanner.nextLine();
            validPassword = checkPasswordComplexity(password);
            if (!validPassword) {
                System.out.println("Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            }
        }

        // Getting first and last name from user
        System.out.print("Enter first name: ");
        firstName = scanner.nextLine();
        System.out.print("Enter last name: ");
        lastName = scanner.nextLine();

        // Registering user with entered information and print result
        String registrationMessage = registerUser(username, password,firstName,lastName);
        System.out.println(registrationMessage);
        
        System.out.println("********************");
        
       // Prompting user for login information
        System.out.println("Login");
        System.out.println("********************");
        
        // Setting up arrays of registered user information for login validation
        String[] registeredUsernames = new String[] {username};
        String[] registeredPasswords = new String[] {password};
        String[] registeredFirstNames = new String[] {firstName};
        String[] registeredLastNames = new String[] {lastName};
        
        // Get login information from user
        System.out.print("Enter username: ");
        username = scanner.nextLine();
        System.out.print("Enter password: ");
        password = scanner.nextLine();
        
        // Validate login information and print result
        String loginStatus = Login.returnLoginStatus(username, password, registeredUsernames, registeredPasswords, registeredFirstNames, registeredLastNames);

        System.out.println("********************");
        System.out.println(loginStatus); 
        System.out.println("*********************");
        
        
         
    }

    // Method to validate username format using regex pattern
    public static boolean checkUserName(String username) {
        Matcher matcher = USERNAME_PATTERN.matcher(username);
        return matcher.matches();
    }

    // Method to validate password format using regex pattern
    public static boolean checkPasswordComplexity(String password) {
        Matcher matcher = PASSWORD_PATTERN.matcher(password);
        return matcher.matches();
    }

    // Method to register user with entered information
    public static String registerUser(String username, String password,String firstName, String lastName) {
        boolean validUsername = checkUserName(username);
        boolean validPassword = checkPasswordComplexity(password);

        if (!validUsername) {
            return "Registration failed: username is not correctly formatted.";
        } else if (!validPassword) {
            return "Registration failed: password is not correctly formatted.";
        } else {
            return "Registration successful!";
           
        }
        
    }
}